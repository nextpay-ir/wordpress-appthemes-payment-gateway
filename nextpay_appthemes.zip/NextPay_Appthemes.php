 
<?php
/*
Plugin Name: 		درگاه پرداخت نکست پی برای محصولات AppThemes
Plugin URI: 		https://nextpay.ir
Description: 		درگاه پرداخت نکست پی برای محصولات Appthemes | شرکت درگاه پرداخت واسط  <a href="https://nextpay.ir">نکست پی</a>
Version: 			1.0.0
Author: 			درگاه پرداخت نکست پی
Author URI: 		https://nextpay.ir
License URI: 		http://www.gnu.org/licenses/gpl-2.0.html
*/
if (!defined( 'ABSPATH' )) 
{
	header('Location: https://nextpay.ir');
	exit;
}
include_once("include/NextPay_Appthemes.php");
?>