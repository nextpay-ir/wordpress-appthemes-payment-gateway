<?php
//redirect nosy to Mahak....
if (!defined( 'ABSPATH' )) {
	header('Location: http://www.nextpay.ir');
	exit;
}
?>